// src/lib/discord.ts

type DiscordUser = {
  id: string;
  username?: string;
  global_name?: string | null;
  avatar?: string | null;
  discriminator?: string;
};

const avatarCache = new Map<string, { url: string; exp: number }>();

// TTL normal pour une réponse OK
const TTL_MS = 6 * 60 * 60 * 1000; // 6h
// TTL court si erreur côté API (rate limit, 5xx)
const TTL_BACKOFF_MS = 5 * 60 * 1000; // 5 min

function getToken(): string | undefined {
  // lazy read (utile en dev/HMR)
  const t = process.env.DISCORD_TOKEN;
  return t && t.trim().length > 0 ? t : undefined;
}

function fallbackAvatar(id: string) {
  // index stable 0..5
  const idx = Number(BigInt(id) % 6n);
  return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
}

function buildAvatarUrl(id: string, hash: string | null | undefined) {
  if (!hash) return fallbackAvatar(id);
  // .png ou .webp — .png marche pour tous
  return `https://cdn.discordapp.com/avatars/${id}/${hash}.png?size=128`;
}

/**
 * Retourne l'URL d'avatar Discord pour un userId.
 * Requiert DISCORD_TOKEN pour interroger l'API ; sinon fallback stable.
 * Met en cache le résultat afin d'éviter de spam l'API.
 */
export async function resolveAvatarUrl(discordId: string): Promise<string> {
  const now = Date.now();

  // Cache hit
  const hit = avatarCache.get(discordId);
  if (hit && hit.exp > now) return hit.url;

  const token = getToken();
  if (!token) {
    const url = fallbackAvatar(discordId);
    avatarCache.set(discordId, { url, exp: now + TTL_MS });
    return url;
  }

  try {
    const res = await fetch(`https://discord.com/api/v10/users/${discordId}`, {
      headers: {
        Authorization: `Bot ${token}`,
        // un petit UA évite certains proxies tatillons
        "User-Agent": "MYG-Inhouses-Site/1.0 (+https://example.com)",
      },
      cache: "no-store",
    });

    if (!res.ok) {
      // 404/403 : l’API ne peut pas renvoyer l’utilisateur => fallback
      const backoff =
        res.status === 429 || res.status >= 500 ? TTL_BACKOFF_MS : TTL_MS;
      const url = fallbackAvatar(discordId);
      avatarCache.set(discordId, { url, exp: now + backoff });
      return url;
    }

    const user = (await res.json()) as DiscordUser;
    const url = buildAvatarUrl(user.id, user.avatar);
    avatarCache.set(discordId, { url, exp: now + TTL_MS });
    return url;
  } catch {
    // Réseau cassé ou autre : fallback + TTL court
    const url = fallbackAvatar(discordId);
    avatarCache.set(discordId, { url, exp: now + TTL_BACKOFF_MS });
    return url;
  }
}
