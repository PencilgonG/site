import { Navbar } from "@/components/Navbar";
export default function FaqPage(){
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-[calc(var(--header-height)+16px)] mx-auto max-w-3xl px-4 pb-16 prose prose-invert">
        <h1>FAQ</h1>
        <p>Questions fréquentes, réponses courtes. (Phase 2)</p>
      </div>
    </main>
  );
}
