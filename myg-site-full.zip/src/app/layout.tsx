import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Myg Inhouse",
  description: "Inhouses MYG – Profils, Matchs, Guides et plus.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-black text-neutral-100 antialiased">
        {children}
      </body>
    </html>
  );
}
