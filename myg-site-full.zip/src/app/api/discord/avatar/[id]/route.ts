import { NextResponse } from "next/server";

type Ctx = { params: { id: string } };

export async function GET(req: Request, { params }: Ctx) {
  const userId = params.id;
  const guildId = process.env.DISCORD_GUILD_ID;
  const token = process.env.DISCORD_BOT_TOKEN;

  // Fallback déterministe
  const fallback = (() => {
    let idx = 0;
    try { idx = Number(BigInt(userId) % 6n); } catch {}
    return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
  })();

  if (!guildId || !token || !userId) {
    return NextResponse.json({ url: fallback }, { status: 200 });
  }

  try {
    const res = await fetch(
      `https://discord.com/api/v10/guilds/${guildId}/members/${userId}`,
      {
        headers: {
          Authorization: `Bot ${token}`,
        },
        cache: "no-store",
      }
    );

    if (!res.ok) {
      // 404 si pas membre, 403 si intents manquants…
      return NextResponse.json({ url: fallback }, { status: 200 });
    }

    const data = await res.json();

    // 1) avatar spécifique de membre (guild-specific avatar)
    const memberAvatar = data?.avatar;
    if (memberAvatar) {
      const url = `https://cdn.discordapp.com/guilds/${guildId}/users/${userId}/avatars/${memberAvatar}.png?size=128`;
      return withCDNCache(url);
    }

    // 2) avatar global utilisateur
    const user = data?.user || {};
    const avatar = user.avatar as string | undefined;
    const discriminator = user.discriminator as string | undefined;

    if (avatar) {
      const ext = avatar.startsWith("a_") ? "gif" : "png";
      const url = `https://cdn.discordapp.com/avatars/${userId}/${avatar}.${ext}?size=128`;
      return withCDNCache(url);
    }

    // 3) pas d’avatar => embed par défaut
    let idx = 0;
    if (discriminator && !Number.isNaN(Number(discriminator))) {
      idx = Number(discriminator) % 6;
    } else {
      try { idx = Number(BigInt(userId) % 6n); } catch {}
    }
    const url = `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
    return withCDNCache(url);
  } catch {
    return NextResponse.json({ url: fallback }, { status: 200 });
  }
}

function withCDNCache(url: string) {
  return new NextResponse(JSON.stringify({ url }), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      // 24h cache public (CDN/browser)
      "cache-control": "public, s-maxage=86400, max-age=86400, stale-while-revalidate=86400",
    },
  });
}
