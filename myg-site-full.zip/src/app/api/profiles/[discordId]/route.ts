import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { resolveAvatarUrl } from "@/lib/discord";

const patchSchema = z.object({
  summonerName: z.string().max(100).nullable().optional(),
  elo: z
    .enum([
      "IRON",
      "BRONZE",
      "SILVER",
      "GOLD",
      "PLATINUM",
      "EMERALD",
      "DIAMOND",
      "MASTER",
      "GRANDMASTER",
      "CHALLENGER",
    ])
    .nullable()
    .optional(),
  mainRole: z
    .enum(["TOP", "JGL", "MID", "ADC", "SUPP", "SUB"])
    .nullable()
    .optional(),
  secondaryRole: z
    .enum(["TOP", "JGL", "MID", "ADC", "SUPP", "SUB"])
    .nullable()
    .optional(),
  opggUrl: z.string().url().nullable().optional(),
  dpmUrl: z.string().url().nullable().optional(),
});

const toUiRole = (db?: string | null) =>
  db === "JGL" ? "JUNGLE" : db === "SUPP" ? "SUPPORT" : (db ?? "SUB");

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ discordId: string }> }
) {
  try {
    const { discordId } = await params;

    const p = await prisma.userProfile.findUnique({
      where: { discordId },
    });
    if (!p) {
      return NextResponse.json({ error: "not_found" }, { status: 404 });
    }

    const [ptsAgg, avatar] = await Promise.all([
      prisma.pointsLedger.aggregate({
        _sum: { points: true },
        where: { discordId },
      }),
      resolveAvatarUrl(discordId),
    ]);

    return NextResponse.json({
      profile: {
        discordId: p.discordId,
        summonerName: p.summonerName,
        elo: p.elo,
        mainRole: p.mainRole,
        secondaryRole: p.secondaryRole,
        opggUrl: p.opggUrl,
        dpmUrl: p.dpmUrl,
        updatedAt: p.updatedAt.toISOString(),
        name: p.summonerName ?? `#${p.discordId.slice(-4)}`,
        avatar,
        points: ptsAgg._sum.points ?? 0,
        uiMainRole: toUiRole(p.mainRole),
      },
    });
  } catch (e) {
    console.error("[GET /api/profiles/:discordId]", e);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}

// Open edit to everyone: use PUT (your modal sends PUT)
export async function PUT(
  req: Request,
  { params }: { params: Promise<{ discordId: string }> }
) {
  try {
    const { discordId } = await params;

    const body = await req.json();
    const parsed = patchSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "invalid_body", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const d = parsed.data;

    const updated = await prisma.userProfile.update({
      where: { discordId },
      data: {
        summonerName: d.summonerName ?? null,
        elo: (d.elo as any) ?? null,
        mainRole: (d.mainRole as any) ?? null,
        secondaryRole: (d.secondaryRole as any) ?? null,
        opggUrl: d.opggUrl ?? null,
        dpmUrl: d.dpmUrl ?? null,
      },
    });

    return NextResponse.json({
      ok: true,
      updatedAt: updated.updatedAt.toISOString(),
    });
  } catch (e) {
    console.error("[PUT /api/profiles/:discordId]", e);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}
