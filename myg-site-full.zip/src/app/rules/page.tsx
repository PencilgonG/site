import { Navbar } from "@/components/Navbar";
export default function RulesPage(){
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-[calc(var(--header-height)+16px)] mx-auto max-w-3xl px-4 pb-16 prose prose-invert">
        <h1>Rules</h1>
        <ul>
          <li>Respect, fair play, pas de flame.</li>
          <li>Être à l’heure pour les matchs.</li>
          <li>Suivre les consignes des responsables.</li>
        </ul>
      </div>
    </main>
  );
}
