"use client";

import Image from "next/image";
import Link from "next/link";
import { Navbar } from "@/components/Navbar";
import LiveMatchesWidget from "@/components/LiveMatchesWidget";
import { TwitchWidget } from "@/components/TwitchWidget";
import UpcomingInhousesWidget from "@/components/UpcomingInhousesWidget";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />

      {/* Hero / bannière */}
      <section className="relative h-[60vh] w-full">
        {/* Fond */}
        <Image
          src="/bg.webp"
          alt=""
          fill
          priority
          className="object-cover opacity-85"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-black/40 to-black" />
        {/* Bannière centrée en bas */}
        <div className="relative h-full flex items-end justify-center pb-10">
          <Image
            src="/banner.png"
            alt="MYG Inhouses"
            priority
            width={700}
            height={200}
            className="h-20 md:h-24 w-auto drop-shadow-[0_6px_24px_rgba(0,0,0,0.5)]"
          />
        </div>
      </section>

      {/* Widgets “plus bas” */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {/* Live matches */}
          <LiveMatchesWidget />

          {/* Twitch */}
          <TwitchWidget />

          {/* Inhouses à venir */}
          <UpcomingInhousesWidget />

          {/* Profils */}
          <Link
            href="/profiles"
            className="rounded-2xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition"
          >
            <h3 className="text-lg font-semibold mb-2">Profils</h3>
            <p className="opacity-80 text-sm">
              Voir tous les joueurs par rôle. Cliquez pour ouvrir la page.
            </p>
          </Link>

          {/* Matchs */}
          <Link
            href="/matches"
            className="rounded-2xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition"
          >
            <h3 className="text-lg font-semibold mb-2">Matchs</h3>
            <p className="opacity-80 text-sm">
              Historique des matchs terminés avec détails.
            </p>
          </Link>

          {/* Guides */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h3 className="text-lg font-semibold mb-2">Guides</h3>
            <p className="opacity-80 text-sm">
              À venir — page d’aide pour l’utilisation du bot et du site.
            </p>
          </div>

          {/* FAQ */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h3 className="text-lg font-semibold mb-2">FAQ</h3>
            <p className="opacity-80 text-sm">
              À venir — réponses aux questions fréquentes des joueurs.
            </p>
          </div>

          {/* Règles */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h3 className="text-lg font-semibold mb-2">Règles</h3>
            <p className="opacity-80 text-sm">
              À venir — règles et bonnes pratiques des inhouses MYG.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
